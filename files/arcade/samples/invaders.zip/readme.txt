Get the latest enhanced Mame samples from: 

www.mameworld.net/dith
